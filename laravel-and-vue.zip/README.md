# Laravel8-Vue3-Bootstrap5

This is a Starter Laravel 8 project with Vue 3 and Bootstrap 5.

## Instalation Guide:

As always you need to:

`composer install`

Then

`npm install`

`npm run dev`

And don't forget the `.env` file and to generate the `APP_KEY` using `php artisan key:generate`

Then you can run:

`php artisan serve`
